# Workout Zine Tracker

A zine-styled workout logging app built with React + Vite.

## Run locally

```bash
npm install
npm run dev
```

## Build for production

```bash
npm run build
```

This outputs a static `dist/` folder you can deploy to any static host
(Vercel, Netlify, GitHub Pages, Cloudflare Pages, etc.).

### Deploying

- **Vercel / Netlify**: just import this project (or drag-and-drop the `dist` folder after building) — build command `npm run build`, output directory `dist`.
- **GitHub Pages**: run `npm run build`, then push the `dist` folder to a `gh-pages` branch (or use the `gh-pages` npm package).
- **Any static host**: upload the contents of `dist/` after building.
